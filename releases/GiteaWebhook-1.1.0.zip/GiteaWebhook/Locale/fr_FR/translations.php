<?php

return array(
    'Gitea webhooks' => 'Webhooks Gitea',
    'Help on Gitea webhooks' => 'Aide sur les webhooks Gitea',
    'Gitea commit received' => 'Commit reçu via Gitea',
    'Bind Gitea webhook events to Kanboard automatic actions' => 'Connecte les événements de Gitea aux actions automatiques de Kanboard',
    'Commit made by %s on Gitea' => 'Commit fait par %s sur Gitea',
);
