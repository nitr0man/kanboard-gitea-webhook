<?php

return array(
    'Gitea webhooks' => 'Gitea webhorgok',
    'Help on Gitea webhooks' => 'Súgó a Gitea webhorgokhoz',
    'Gitea commit received' => 'Gitea kommit érkezett',
    'Bind Gitea webhook events to Kanboard automatic actions' => 'Gitea webhorog események kötése a Kanboard automatikus műveleteihez',
    'Commit made by @%s on Gitea' => '@%s által készített kommit a Gitea oldalon',
);
